# Changelog

## 0.1.8 - 2026-08-08

- Added the short video `How a Justfile Fixes AI Coding Agents` under `videos/` and linked it from the README.
- Added the video to the explicit release manifest and package regression coverage.
- Excluded Windows `Zone.Identifier` metadata from Git tracking and release packages.

## 0.1.7 - 2026-07-11

- Updated the README download instructions to point directly to the published release.
- Removed stale v0.1.6 release-candidate wording.
- Preserved the published v0.1.6 tag and release asset without modification.

## 0.1.6 - 2026-07-11

- Added a copy-paste prompt for creating a durable justfile-first rule in `AGENTS.md` or another project agent instruction file.
- Updated setup prompts and beginner flows so agents add the durable rule after verifying the justfile.
- Added beginner guidance explaining how the justfile and agent instruction file work together.
- Added user review and confirmation as required setup completion steps.
- Added release regression coverage and v0.1.6 packaging references.

## 0.1.5 - 2026-07-11

- Added Bill Watson's revised beginner article and its exact 5:2 header image.
- Corrected `justx run` examples to use verified source-qualified targets.
- Removed the false recipe-prefix abbreviation claim and pointed readers to explicit aliases.
- Quoted user-controlled parameters in key tutorial recipes and added shell-safety guidance.
- Kept `justx` optional in the default validation workflow while retaining an explicit strict check.
- Made malformed justfile encoding a clean validator error instead of a traceback.
- Replaced broad recursive ZIP packaging with an explicit distribution manifest.
- Added validator and release regression tests and strengthened `agent-verify`.
- Updated release links and packaging for v0.1.5.

## 0.1.4 - 2026-07-03

- Cleaned internal references from changelog, made tutorial example name generic, expanded `.gitignore` for public distribution.
- Updated README and packaging references for the v0.1.4 zip.

## 0.1.3 - 2026-07-03

- Changed the quick-start install prompt wording to say `optional justx`.
- Updated README and packaging references for the v0.1.3 zip.

## 0.1.2 - 2026-07-03

- Made the install prompt align with optional `justx` setup.
- Added `default:` to the quick-start card's minimum starter recipe block.
- Renamed the validator's starter recipe set from required to recommended and added `default`.
- Clarified that missing starter recipes are validator warnings unless core setup checks fail.
- Updated README and packaging references for the v0.1.2 zip.

## 0.1.1 - 2026-07-02

- Narrowed Windows wording to WSL/Git Bash/MSYS/Bash-compatible shell path.
- Made `justx` optional in the friendly agent workflow.
- Corrected `justx run -g` examples to use source-qualified global recipes.
- Softened `set unstable` wording.
- Fixed validator parsing for parameterized recipes.
- Added README path chooser, safety note, download-without-Git instructions, and validator usage examples.
- Added `default:` to starter justfiles and root repo justfile.
- Normalized runbook heading numbering.
- Cleaned `examples/basic-justfile` output behavior.

## 0.1.0 - 2026-07-02

- Created first standalone draft package.
- Added main runbook, quick-start card, prompts, examples, starter justfile, checker script, and validation tooling.
- Revised starter recipes so non-Git folders show a friendly message instead of a fatal Git error.
- Removed references to unrelated runbook projects from user-facing package text.
- Added teaching prompt and included a step-by-step tutorial at `tutorial/justfile-and-justx-tutorial.md`.
- Added supported-platforms guidance for Linux, WSL, Windows, and macOS.
- Added first-20-minutes and success-check guidance for brand-new users.
- Corrected tutorial `justx` install/repository details and clarified that the tutorial is optional deeper learning.
- Removed specific internal agent-tool examples from the main runbook wording.
- Completed disposable-folder smoke test for a fresh project using the starter justfile.
- Added README mini-article explaining why justfiles matter for users, agents, and inference cost.
- Added packaging plan and zip distribution setup.
- Applied external review corrections: guarded tutorial menu recipes, added apt caveat, updated release-candidate status, clarified duplicate starter/example files, labeled example version output, and made tutorial paths generic.
- Added public-repo `.gitignore`.
